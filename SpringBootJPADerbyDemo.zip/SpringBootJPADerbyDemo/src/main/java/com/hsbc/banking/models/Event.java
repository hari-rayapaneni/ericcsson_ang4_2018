package com.hsbc.banking.models;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Generated;

@Entity
@Table(name="HSBC_Event")
public class Event {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) 
    @Column(name="Event_Id")
	private int eventId;
    @Column(name="Event_Name",nullable=false,length=50)
	private String name;
    @Column(name="Location",nullable=false,length=50)
	private String location;
    @Column(name="Event_Date",nullable=false)
  	private String eventDate;
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	
}
