package com.hsbc.banking.repositories;

import org.springframework.data.repository.CrudRepository;

import com.hsbc.banking.models.Event;

public interface EventRepository extends CrudRepository<Event,Integer>{

}
