package com.hsbc.banking.models;

public class State {
	private int stateCode;
	private String stateName;
	private String countryCode;
	
	public State()
	{
		this.stateCode = 0;
		this.stateName = null;
		this.countryCode = null;
	}
	public State(int stateCode, String stateName, String countryCode) {
		super();
		this.stateCode = stateCode;
		this.stateName = stateName;
		this.countryCode = countryCode;
	}
	public int getStateCode() {
		return stateCode;
	}
	public void setStateCode(int stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	

}
