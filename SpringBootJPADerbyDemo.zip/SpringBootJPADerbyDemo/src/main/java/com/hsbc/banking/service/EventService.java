package com.hsbc.banking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsbc.banking.models.Event;
import com.hsbc.banking.repositories.EventRepository;

@Service
public class EventService {
	@Autowired
	private EventRepository eventRepo;
	
	public void saveEvent(Event event)
	{
		eventRepo.save(event);//insert query
		
	}
	public void updateEvent(Event event,Integer eventId)
	{
		eventRepo.save(event);//update query	
	}
	public void deleteEvent(Integer eventId)
	{
		eventRepo.delete(eventId);//update query	
	}

	public List<Event> getAllEvents()
	{
		List<Event> eventList=new ArrayList<Event>();
		eventRepo.findAll().forEach(eventList::add);//select all
		return eventList;
	}
	
	public Event getEventById(Integer eventId)
	{
		return eventRepo.findOne(eventId);//select with where 
	}
	
}
