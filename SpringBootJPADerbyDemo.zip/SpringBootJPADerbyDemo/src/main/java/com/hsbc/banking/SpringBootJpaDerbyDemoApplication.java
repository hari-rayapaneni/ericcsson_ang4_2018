package com.hsbc.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages="com.hsbc.banking.*")
public class SpringBootJpaDerbyDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaDerbyDemoApplication.class, args);
	}
}
