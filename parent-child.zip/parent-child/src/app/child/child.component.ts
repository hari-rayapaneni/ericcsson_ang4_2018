import {Component, EventEmitter, Input, Output} from "@angular/core";


@Component({
  selector:'app-child',
  templateUrl:'./child.component.html',
  styleUrls:['./child.component.css']
})
export class ChildComponent{

  childMessage:string="test";



  @Output('ngUpdate')
  private messageUpdate=new EventEmitter<any>();

  @Input() messageInput:string;

  messageEvent()
  {
    this.messageUpdate.emit();
  }

}
