import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {MatButtonModule, MatFormFieldModule, MatInput, MatInputModule} from "@angular/material";
import {FormsModule} from "@angular/forms";
import {ChildComponent} from "./child/child.component";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";

@NgModule({
  declarations: [
    AppComponent,ChildComponent
  ],
  imports: [
    BrowserModule,MatButtonModule, MatFormFieldModule,
    BrowserAnimationsModule,MatInputModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
