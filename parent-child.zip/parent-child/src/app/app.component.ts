import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {ChildComponent} from "./child/child.component";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit{

  private message:string;
  private updatedData:string;
  @ViewChild(ChildComponent)
  private childComp:ChildComponent;

  updateMessage()
  {
    this.updatedData=this.message.toUpperCase();
    console.log(this.message)
  }
  ngAfterViewInit(): void {
        console.log(this.childComp.childMessage);
  }

}
