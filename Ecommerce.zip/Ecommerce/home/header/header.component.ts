import {Component} from "@angular/core";


@Component({
    selector:'ecomm-header',
    templateUrl:'./home/header/header.component.html',
    styleUrls:['./home/header/header.component.css']
})

export class HeaderComponent
{
    private logoPath:string;
    private bannerPath:string;

    constructor()
    {
        this.logoPath="./home/images/logo.png";
        this.bannerPath="./home/images/banner.jpg";
    }


}