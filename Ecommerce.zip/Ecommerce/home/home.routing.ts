import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {LoginComponent} from "./login/login.component";
import {RegisterComponent} from "./register/register.component";
import {ProductModule} from "./product/product.module";
import {FeedbackComponent} from "./feedback/feedback.component";


var  routes:Routes=[

    {
        path:'Login',
        component:LoginComponent
    },
    {
        path:'Product',
        loadChildren: () => ProductModule
    },
    {
        path:'Register',
        component:RegisterComponent
    },
    {
        path:'Feedback',
        component:FeedbackComponent
    },
]

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class HomeRoutingModule{

}