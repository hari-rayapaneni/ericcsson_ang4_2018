import {NgModule} from "@angular/core";
import {RouterModule, Routes} from "@angular/router";
import {FurnitureComponent} from "../furniture/furniture.component";
import {GarmentsComponent} from "../garments/garments.component";
import {ElectronicsComponent} from "../electronics/electronics.component";
import {ProductComponent} from "./product.component";
import {AuthGuardService} from "../service/service.authguard";

var routes:Routes=[
    {
        path: 'Product',
        component: ProductComponent,
        canActivate: [ AuthGuardService ],
        children:[
    {
        path: 'Electronics',
        component: ElectronicsComponent
    },
    {
        path: 'Furniture',
        component: FurnitureComponent
    },
    {
        path: 'Garments',
        component: GarmentsComponent
    }]
}
]

@NgModule({
    imports:[RouterModule.forChild(routes)],
    exports:[RouterModule]
})
export class ProductRoutingModule
{

}


