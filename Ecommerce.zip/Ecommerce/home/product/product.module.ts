import {NgModule} from "@angular/core";
import {ElectronicsComponent} from "../electronics/electronics.component";
import {FurnitureComponent} from "../furniture/furniture.component";
import {GarmentsComponent} from "../garments/garments.component";
import {ProductRoutingModule} from "./product.routing";
import {ProductComponent} from "./product.component";
import {MatButtonModule} from "@angular/material";
import {CommonModule} from "@angular/common";


@NgModule({
    imports:[CommonModule,ProductRoutingModule,MatButtonModule],
    declarations:[ProductComponent,ElectronicsComponent,FurnitureComponent,GarmentsComponent]
})
export class ProductModule
{

}