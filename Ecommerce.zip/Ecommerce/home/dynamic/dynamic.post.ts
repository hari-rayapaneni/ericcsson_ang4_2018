export interface MyPost {
    post: any;
}