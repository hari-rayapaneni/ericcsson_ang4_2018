import {Component, OnInit} from "@angular/core";
import {MenuService} from "../service/service.menuservice";


@Component({
    selector:'ecomm-menu',
    templateUrl:'./home/menu/menu.component.html',
    styleUrls:['./home/menu/menu.component.css']
})
export class MenuComponent implements OnInit{

    private menuData:any;
    constructor(private menuServiceObj:MenuService)
    {

    }

    ngOnInit()
    {
        this.menuData=this.menuServiceObj.getMenuItems();
    }

}