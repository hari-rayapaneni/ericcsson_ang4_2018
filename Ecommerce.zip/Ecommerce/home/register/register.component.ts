import {Component, OnInit} from "@angular/core";
import {CountryService} from "../service/service.country";
import {State} from "../model/model.state";


@Component({
    templateUrl:'./home/register/register.component.html',
    styleUrls:['./home/register/register.component.css']
})
export class RegisterComponent implements OnInit{
    private selectedGender:string="Male";
    genderOptions:string[] = [
        'Male',
        'Female'
    ];
    private countries:any;
    private states:any;
    constructor(private countryServiceObj:CountryService)
    {

    }
    ngOnInit()
    {
        this.countryServiceObj.getAllCountries().subscribe(response=>{
            this.countries=response;
            console.log(this.countries);
        })
    }


    selectedCountry(data)
    {
        console.log(data.value.alpha3Code);
        //this.states=this.countryServiceObj.getAllStatesByCode(data.value.alpha3Code);

         var stateObj=new State(0,"",data.value.alpha3Code);
        this.countryServiceObj.getAllStatesByCode(stateObj)
            .subscribe(response=>{
                console.log(response);
            this.states=response;
        })
    }
}