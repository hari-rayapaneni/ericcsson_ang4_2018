import {Injectable} from "@angular/core";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Observable} from "rxjs/Observable";
import {State} from "../model/model.state";
//import {stateData} from "../model/model.statedata";

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type':  'application/json'
    })
};
@Injectable()
export class CountryService{


    constructor(private http:HttpClient)
    {

    }

    getAllCountries():Observable<any>
    {
       return this.http.get<any>("https://restcountries.eu/rest/v2/all");

    }
    getAllStatesByCode(state:State):Observable<any>
    {
        //return stateData.filter(obj=>obj.CountryCode===code);

        return this.http.post<State>('http://localhost:6060/getStateByCode',
            state, httpOptions);

    }

    private handleErrorObservable (error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.message || error);
    }


}