import {Injectable} from "@angular/core";
import {Menu} from "../model/model.menu";
import {menuItems, productSubMenu} from "../model/model.menuitems";


@Injectable()
export class MenuService{

 getMenuItems():Menu[]
 {
     return menuItems;
 }

  getProductSubMenu():string[]
  {
      return productSubMenu;
  }

}



