import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {HomeComponent} from "./home.component";
import {HeaderComponent} from "./header/header.component";
import {MenuComponent} from "./menu/menu.component";
import {MenuService} from "./service/service.menuservice";
import {HomeRoutingModule} from "./home.routing";
import {
    MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatRadioModule,
    MatSelectModule
} from "@angular/material";
import {LoginComponent} from "./login/login.component";
import {RegisterComponent} from "./register/register.component";
import {ProductModule} from "./product/product.module";
import {AuthService} from "./service/service.authenticationservice";
import {AuthGuardService} from "./service/service.authguard";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {HttpClientModule} from "@angular/common/http";
import {CountryService} from "./service/service.country";

//sub module added  before main routing module
@NgModule({
    imports:[BrowserModule,ProductModule,HomeRoutingModule,
        MatButtonModule,MatFormFieldModule,
        MatInputModule,MatRadioModule,FormsModule,ReactiveFormsModule,MatIconModule,
        BrowserAnimationsModule,HttpClientModule,MatSelectModule],
    declarations:[HomeComponent,HeaderComponent,MenuComponent,
        LoginComponent,RegisterComponent],
    providers:[MenuService,AuthService,AuthGuardService,CountryService],
    bootstrap:[HomeComponent]
})
export class HomeModule
{

}