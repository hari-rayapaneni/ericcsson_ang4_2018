import {Menu} from "./model.menu";

export var menuItems:Menu[]=[
    new Menu(1,"Product"),
    new Menu(2,"Login"),
    new Menu(3,"Register"),
    new Menu(4,"Feedback"),
    new Menu(5,"About Us"),

]


export var productSubMenu:string[]=
    ["Electronics","Furniture","Garments"]