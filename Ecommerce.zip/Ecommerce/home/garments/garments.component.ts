import {Component} from "@angular/core";


@Component({
    templateUrl:'./home/garments/garments.component.html',
    styleUrls:['./home/garments/garments.component.css']
})
export class GarmentsComponent{

}